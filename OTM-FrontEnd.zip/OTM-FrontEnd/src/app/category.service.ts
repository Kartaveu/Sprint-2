import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Category } from './category';
//import { Delete } from './delete';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

 // private accounts:Account[]=[];

  constructor(private http:HttpClient) { }

  public showallcategory():Observable<any>{
    console.log("Am inside service");
    return this.http.get("http://localhost:8004/viewallcategory");
  }

  // setAccounts(categories:Category[]):void{
  //   this.categories=categories;
  // }

  // getCategories():Category[]{
  //   return this.categories;
  // }
  // getCategory(categoryId: number): Observable<any> {
  //   return this.http.get('http://localhost:8004/viewallcategory'+categoryId);
  // }


  public addCategory(category:Category):Observable<any>{
    return this.http.post("http://localhost:8004/addcategory",category,{responseType:'text'});
  }

  public deleteCategory(categoryId:number):Observable<any>{
  return this.http.delete("http://localhost:8004/deletecategory/"+categoryId,{responseType:'text'});
  }

  updateCategory(category: Category): Observable<Object> {
    
    return this.http.put("http://localhost:8004/updateCategory",category,{responseType: 'text' });
  }
  

}
