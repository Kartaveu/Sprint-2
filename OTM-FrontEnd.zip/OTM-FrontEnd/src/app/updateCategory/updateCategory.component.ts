import { Component, OnInit } from '@angular/core';
import { Category } from '../category';
import { CategoryService } from '../category.service';

@Component({
  selector: 'app-UpdateCategory',
  templateUrl: './UpdateCategory.component.html',
  styleUrls: ['./UpdateCategory.component.css']
})
export class UpdateCategoryComponent implements OnInit {
  category: Category = new Category();
msg: string;
errormsg: string;

  constructor(private categoryservice: CategoryService) { }

  ngOnInit(): void {
  }
  updateCategory(){
    this.categoryservice.updateCategory(this.category).subscribe((data) => {
      console.log(data);
      this.msg = data;
      this.errormsg = undefined;
      this.category= new Category(); },
      error => {this.errormsg = JSON.parse(error.error).msg;
                console.log(error.error);
                this.msg = undefined; });
    }

  }


