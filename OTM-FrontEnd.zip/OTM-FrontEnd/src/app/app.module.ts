import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddcategoryComponent } from './addCategory/addCategory.component';
import { ShowallcategoryComponent } from './showallcategory/showallcategory.component';

import { HttpClient, HttpClientModule } from '@angular/common/http';
import { UpdateCategoryComponent } from './updateCategory/updateCategory.component';
import { DeletecategoryComponent } from './deletecategory/deletecategory.component';

@NgModule({
  declarations: [
    AppComponent,
    AddcategoryComponent,
    ShowallcategoryComponent,
   
    UpdateCategoryComponent,
   DeletecategoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
