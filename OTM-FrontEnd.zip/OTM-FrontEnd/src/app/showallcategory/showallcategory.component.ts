import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../category.service';
import { Category } from '../category';


@Component({
  selector: 'app-showallcategory',
  templateUrl: './showallcategory.component.html',
  styleUrls: ['./showallcategory.component.css']
})
export class ShowallcategoryComponent implements OnInit {

  categories:Category[]=[];

  constructor(private categoryService:CategoryService) { }

  ngOnInit(): void {
    console.log("Am inside show category");
    this.categoryService.showallcategory().subscribe(data=>this.categories=data);
    console.log(this.categories);
  }

}



