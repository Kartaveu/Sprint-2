import { Component, OnInit } from '@angular/core';
import { Category } from '../category';
import { CategoryService } from '../category.service';

@Component({
  selector: 'app-deletecategory',
  templateUrl: './deletecategory.component.html',
  styleUrls: ['./deletecategory.component.css']
})
export class DeletecategoryComponent implements OnInit {

  categoryId:number=0;
  msg:String;
  errorMsg:String;
  constructor(private categoryService:CategoryService) { }

ngOnInit(): void {
  }

  deletecategory(){
    console.log(this.categoryId);

    this.categoryService.deleteCategory(this.categoryId).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.categoryId=null;},
      error=>{this.errorMsg=JSON.parse(error.error).msg;
        console.log(error.error);
        this.msg=undefined});
  }

}


