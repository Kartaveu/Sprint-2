import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowallcategoryComponent } from './showallcategory/showallcategory.component';
import { AddcategoryComponent } from './addCategory/addCategory.component';
import { DeletecategoryComponent } from './deletecategory/deletecategory.component';

import { UpdateCategoryComponent } from './updateCategory/updateCategory.component';

const routes: Routes = [
  {path:'showallcategory', component:ShowallcategoryComponent},
  {path:'addCategory', component:AddcategoryComponent},
  {path:'deletecategory',component:DeletecategoryComponent},
  {path:'updateCategory', component:UpdateCategoryComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
