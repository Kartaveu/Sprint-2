import { Component, OnInit } from '@angular/core';
import { Category } from '../category';
import { CategoryService } from '../category.service';

@Component({
  selector: 'app-addCategory',
  templateUrl: './addCategory.component.html',
  styleUrls: ['./addCategory.component.css']
})
export class AddcategoryComponent implements OnInit {

  category:Category=new Category();
  msg:String;
  errorMsg:String;
  constructor(private categoryService:CategoryService) { }

  ngOnInit(): void {
  }

  addCategory(){
    console.log("Inside AddCategory");
    this.categoryService.addCategory(this.category).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.category=new Category()},
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined});

      

}
}
